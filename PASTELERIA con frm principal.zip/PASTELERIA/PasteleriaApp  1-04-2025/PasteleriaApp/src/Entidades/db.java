package Entidades;

public class db {
    private int clientes;
    private int detallespedido;
    private int empleados;
    private int ingredientes;
    private int pedidos;
    private int productos;
    private int productos_ingredientes;
    private boolean activo;

    public db(int clientes, int detallespedido, int empleados, int ingredientes, int pedidos, int productos, int productos_ingredientes, boolean activo) {
        this.clientes = clientes;
        this.detallespedido = detallespedido;
        this.empleados = empleados;
        this.ingredientes = ingredientes;
        this.pedidos = pedidos;
        this.productos = productos;
        this.productos_ingredientes = productos_ingredientes;
        this.activo = activo;
    }

    public int getClientes() {
        return clientes;
    }

    public void setClientes(int clientes) {
        this.clientes = clientes;
    }

    public int getDetallespedido() {
        return detallespedido;
    }

    public void setDetallespedido(int detallespedido) {
        this.detallespedido = detallespedido;
    }

    public int getEmpleados() {
        return empleados;
    }

    public void setEmpleados(int empleados) {
        this.empleados = empleados;
    }

    public int getIngredientes() {
        return ingredientes;
    }

    public void setIngredientes(int ingredientes) {
        this.ingredientes = ingredientes;
    }

    public int getPedidos() {
        return pedidos;
    }

    public void setPedidos(int pedidos) {
        this.pedidos = pedidos;
    }

    public int getProductos() {
        return productos;
    }

    public void setProductos(int productos) {
        this.productos = productos;
    }

    public int getProductos_ingredientes() {
        return productos_ingredientes;
    }

    public void setProductos_ingredientes(int productos_ingredientes) {
        this.productos_ingredientes = productos_ingredientes;
    }

    public boolean isActivo() {
        return activo;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }

    @Override
    public String toString() {
        return "db{" + "clientes=" + clientes + ", detallespedido=" + detallespedido + ", empleados=" + empleados + ", ingredientes=" + ingredientes + ", pedidos=" + pedidos + ", productos=" + productos + ", productos_ingredientes=" + productos_ingredientes + ", activo=" + activo + '}';
    }
    
    
    
}



