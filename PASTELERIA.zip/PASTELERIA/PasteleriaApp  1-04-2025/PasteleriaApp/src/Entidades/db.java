package Entidades;

public class db {
    
    private int id;
    private String clientes;
    private String detallespedido;
    private String empleados;
    private String ingredientes;
    private String pedidos;
    private String productos;
    private String productos_ingredientes;
    private boolean activo;

    public db(int id, String clientes, String detallespedido, String empleados, String ingredientes, String pedidos, String productos, boolean activo) {
        this.id = id;
        this.clientes = clientes;
        this.detallespedido = detallespedido;
        this.empleados = empleados;
        this.ingredientes = ingredientes;
        this.pedidos = pedidos;
        this.productos = productos;
        this.productos_ingredientes = productos_ingredientes;
        this.activo = activo;
    }

    public db() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getClientes() {
        return clientes;
    }

    public void setClientes(String clientes) {
        this.clientes = clientes;
    }

    public String getDetallespedido() {
        return detallespedido;
    }

    public void setDetallespedido(String detallespedido) {
        this.detallespedido = detallespedido;
    }

    public String getEmpleados() {
        return empleados;
    }

    public void setEmpleados(String empleados) {
        this.empleados = empleados;
    }

    public String getIngredientes() {
        return ingredientes;
    }

    public void setIngredientes(String ingredientes) {
        this.ingredientes = ingredientes;
    }

    public String getPedidos() {
        return pedidos;
    }

    public void setPedidos(String pedidos) {
        this.pedidos = pedidos;
    }

    public String getProductos() {
        return productos;
    }

    public void setProductos(String productos) {
        this.productos = productos;
    }

    public String getProductos_ingredientes() {
        return productos_ingredientes;
    }

    public void setProductos_ingredientes(String productos_ingredientes) {
        this.productos_ingredientes = productos_ingredientes;
    }

    public boolean isActivo() {
        return activo;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }

    @Override
    public String toString() {
        return "db{" + "id=" + id + ", clientes=" + clientes + ", detallespedido=" + detallespedido + ", empleados=" + empleados + ", ingredientes=" + ingredientes + ", pedidos=" + pedidos + ", productos=" + productos + ", productos_ingredientes=" + productos_ingredientes + ", activo=" + activo + '}';
    }

    
 
}



