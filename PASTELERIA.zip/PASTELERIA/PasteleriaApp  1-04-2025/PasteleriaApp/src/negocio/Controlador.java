package negocio;

import Datos.dbDAO;
import Entidades.db;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author JcarlosAd7
 */
public class Controlador {
    private final dbDAO DATOS;
    private final db obj;
    private DefaultTableModel modeloTabla;
    public int registrosMostrados;
    
    public Controlador(){
        this.DATOS=new dbDAO();
        this.obj=new db();
        this.registrosMostrados=0;
    }
    
    public DefaultTableModel listar(String texto){
        List<db> lista=new ArrayList();
        lista.addAll(DATOS.listar(texto));
        
        String[] titulos={"Id","Nombre","Descripción","Estado"};
        this.modeloTabla=new DefaultTableModel(null,titulos);        
        
        String estado;
        String[] registro = new String[4];
        
        this.registrosMostrados=0;
        for (db item:lista){
            if (item.isActivo()){
                estado="Activo";
            } else{
                estado="Inactivo";
            }
            registro[0]=Integer.toString(item.getId());
            registro[1]=item.getClientes();
            registro[2]=item.getDetallespedido();
            registro[2]=item.getEmpleados();
            registro[2]=item.getIngredientes();
            registro[2]=item.getPedidos();
            registro[2]=item.getProductos();
            registro[2]=item.getProductos_ingredientes();
            registro[7]=estado;
            this.modeloTabla.addRow(registro);
            this.registrosMostrados=this.registrosMostrados+1;
        }
        return this.modeloTabla;
    }
    
    public String insertar(String clientes, String detallespedido, String empleados, String ingredientes, String pedidos, String productos, String productos_ingredientes){
        if (DATOS.existe(clientes)){
            return "El registro ya existe.";
        }else{
          
            obj.setClientes(clientes);
            obj.setDetallespedido(detallespedido);
            obj.setEmpleados(empleados);
            obj.setIngredientes(ingredientes);
            obj.setPedidos(pedidos);
            obj.setProductos(productos);
            obj.setProductos_ingredientes(productos_ingredientes);
            if (DATOS.insertar(obj)){
                return "OK";
            }else{
                return "Error en el registro.";
            }
        }
    }
    
    public String actualizar(int id, String clientes,String clienteAnt, String detallespedido, String empleados, String ingredientes, String pedidos, String productos, String productos_ingredientes){
        if (clientes.equals(clienteAnt)){
            obj.setId(id);
            obj.setClientes(clientes);
            obj.setDetallespedido(detallespedido);
            obj.setEmpleados(empleados);
            obj.setIngredientes(ingredientes);
            obj.setPedidos(pedidos);
            obj.setProductos(productos);
            obj.setProductos_ingredientes(productos_ingredientes);
            if(DATOS.actualizar(obj)){
                return "OK";
            }else{
                return "Error en la actualización.";
            }
        }else{
            if (DATOS.existe(clientes)){
                return "El registro ya existe.";
            }else{
            obj.setId(id);
            obj.setClientes(clientes);
            obj.setDetallespedido(detallespedido);
            obj.setEmpleados(empleados);
            obj.setIngredientes(ingredientes);
            obj.setPedidos(pedidos);
            obj.setProductos(productos);
            obj.setProductos_ingredientes(productos_ingredientes);
                if (DATOS.actualizar(obj)){
                    return "OK";
                }else{
                    return "Error en la actualización.";
                }
            }
        }
    }
    
    public String desactivar(int id){
        if (DATOS.desactivar(id)){
            return "OK";
        }else{
            return "No se puede desactivar el registro";
        }
    }
    
    public String activar(int id){
        if (DATOS.activar(id)){
            return "OK";
        }else{
            return "No se puede activar el registro";
        }
    }
    
    public int total(){
        return DATOS.total();
    }
    
    public int totalMostrados(){
        return this.registrosMostrados;
    }
}
