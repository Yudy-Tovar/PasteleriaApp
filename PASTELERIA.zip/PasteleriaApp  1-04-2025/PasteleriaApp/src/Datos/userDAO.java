package Datos;

import DataBase.Conexion;
import Entidades.db;


public class dbDAO implements Crud<db> {
    
    private final Conexion CON;
    private PreparedStatement ps;
    private ResultSet rs;
    private boolean resp;
    
public CategoriaDAO(){
    ///es el objeto q se creo 
        CON=Conexion.getInstancia();
}
