package CRUD;

import java.util.List;


public interface Crud<T> {
   public List<T> listar(String texto);
   public boolean insertar(T obj);
   public boolean actualizar(T obj);
   public boolean desactivar(int id);
   public boolean activar(int id);
   public int total();
   public boolean existe(String texto);
}




/*
escalable. 
beneficios reales.
MODIFICACIONES modulos.
SOCIAL. EJEMPLO COMO EL CASO DE UNA EPS, COMO EL BUS QUE AUNQUE ESTAN SUBSIDIADOS AUN ASI HAY Q PAGAR
ESTUDIO DEL ARTE . VER EN QUE SE PUEDE DISTINGUI MI PROYECTO DEL RESTO
REUTILIZABLE.
DICIONARRIO. COJER LA TABLA Y DECIR PARA QUE ES CADA COSA Y CON Q OTRAS TABLAS TIENE CONXION LOS ATRIBUTOS DE ESA TABLA CUALES SON Y ARGUMENTAR CADA UNO DE ELLOS: NOBRE TABLA, ATRIBUTO, UNA BREBE DESCRIPCION Y A QUE TABLAS APUNTA
NUEVA R R(ENTIDAD RELACION).EJEMPLO CREAR UN NUEVO MODULO PARA VENDER EL PRODUCTO ,SI VOY A VENDER EL PAN INCLUSO ANTES DE AVERLO HECHO  
VERIFICACION PROYECTO
VENTANAS

*/