package Datos;

import CRUD.Crud;
import DataBase.Conexion;
import Entidades.db;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;




public class dbDAO implements Crud<db> {
    //CON espara crear el objeto
    private final Conexion CON;
    private PreparedStatement ps;
    private ResultSet rs;
    private boolean resp;
    
public dbDAO(){
    ///es el objeto q se creo //getInstancia llama al componente de conexion
        CON=Conexion.getInstancia();
}
 
    @Override
    public List<db> listar(String texto) {
        List<db> registros=new ArrayList();
        try {
            ps=CON.conectar().prepareStatement("SELECT * FROM db WHERE cliente LIKE ?");
            ps.setString(1,"%" + texto +"%");
            rs=ps.executeQuery();
            while(rs.next()){
                registros.add(new db(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getBoolean(8)));
            }
            ps.close();
            rs.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        } finally{
            ps=null;
            rs=null;
            CON.desconectar();
        }
        return registros;
    }

    @Override
    public boolean insertar(db obj) {
        resp=false;
        try {
            ps=CON.conectar().prepareStatement("INSERT INTO db (clientes,detallespedido,empleados,ingrediente,pedidos,productos,productos_ingredientes,activo) VALUES (?,?,1)");
            ps.setString(1, obj.getClientes());
            ps.setString(2, obj.getDetallespedido());
            ps.setString(3, obj.getEmpleados());
            ps.setString(4, obj.getIngredientes());
            ps.setString(5, obj.getPedidos());
            ps.setString(6, obj.getProductos());
            ps.setString(7, obj.getProductos_ingredientes());

            if (ps.executeUpdate()>0){
                resp=true;
            }
            ps.close();
        }  catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        } finally{
            ps=null;
            CON.desconectar();
        }
        return resp;
    }

    @Override
    public boolean actualizar(db obj) {
        resp=false;
        try {
            ps=CON.conectar().prepareStatement("UPDATE db SET clientes=?,detallespedido=?,empleados=?,ingrediente=?,pedidos=?,productos=?,productos_ingredientes WHERE id=?");
            ps.setString(1, obj.getClientes());
            ps.setString(2, obj.getDetallespedido());
            ps.setString(3, obj.getEmpleados());
            ps.setString(4, obj.getIngredientes());
            ps.setString(5, obj.getPedidos());
            ps.setString(6, obj.getProductos());
            ps.setString(7, obj.getProductos_ingredientes());
           

            if (ps.executeUpdate()>0){
                resp=true;
            }
            ps.close();
        }  catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        } finally{
            ps=null;
            CON.desconectar();
        }
        return resp;
    }

    @Override
    public boolean desactivar(int id) {
        resp=false;
        try {
            ps=CON.conectar().prepareStatement("UPDATE db SET activo=0 WHERE id=?");
            ps.setInt(1, id);
            if (ps.executeUpdate()>0){
                resp=true;
            }
            ps.close();
        }  catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        } finally{
            ps=null;
            CON.desconectar();
        }
        return resp;
    }

    @Override
    public boolean activar(int id) {
        resp=false;
        try {
            ps=CON.conectar().prepareStatement("UPDATE db SET activo=1 WHERE id=?");
            ps.setInt(1, id);
            if (ps.executeUpdate()>0){
                resp=true;
            }
            ps.close();
        }  catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        } finally{
            ps=null;
            CON.desconectar();
        }
        return resp;
    }

    @Override
    public int total() {
        int totalRegistros=0;
        try {
            ps=CON.conectar().prepareStatement("SELECT COUNT(id) FROM db");            
            rs=ps.executeQuery();
            
            while(rs.next()){
                totalRegistros=rs.getInt("COUNT(id)");
            }            
            ps.close();
            rs.close();
        }  catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        } finally{
            ps=null;
            rs=null;
            CON.desconectar();
        }
        return totalRegistros;
    }

    @Override
    public boolean existe(String texto) {
        resp=false;
        try {
            ps=CON.conectar().prepareStatement("SELECT clientes FROM db WHERE clientes=?");
            ps.setString(1, texto);
            rs=ps.executeQuery();
            rs.last();
            if(rs.getRow()>0){
                resp=true;
            }           
            ps.close();
            rs.close();
        }  catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        } finally{
            ps=null;
            rs=null;
            CON.desconectar();
        }
        return resp;
    }
}